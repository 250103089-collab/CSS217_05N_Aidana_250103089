@echo off
setlocal
cd /d "%~dp0"
if not exist "build\classes" mkdir "build\classes"
if not exist "output" mkdir "output"
if exist "build\sources.txt" del "build\sources.txt"
for /r "src" %%F in (*.java) do @echo "%%F">>"build\sources.txt"
for /r "tests" %%F in (*.java) do @echo "%%F">>"build\sources.txt"
javac -source 8 -target 8 -d "build\classes" @"build\sources.txt"
if errorlevel 1 exit /b 1
(
    echo ========== AUTOMATED REGRESSION TESTS ==========
    java -cp "build\classes" tests.DesignPatternsTests
    echo.
    echo ========== TASK 1 RUNNER ==========
    java -cp "build\classes" task1.Task1Runner
    echo.
    echo ========== TASK 2 RUNNER ==========
    java -cp "build\classes" task2.Task2Runner
    echo.
    echo ========== TASK 3 RUNNER ==========
    java -cp "build\classes" task3.Task3Runner
    echo.
    echo ========== TASK 4 RUNNER ==========
    java -cp "build\classes" task4.Task4Runner
    echo.
    echo ========== TASK 5 RUNNER ==========
    java -cp "build\classes" task5.Task5Runner
) > "output\verification.txt"
type "output\verification.txt"
endlocal
