#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/classes output
find src tests -name '*.java' | sort > build/sources.txt
javac -source 8 -target 8 -Xlint:-options -d build/classes @build/sources.txt
{
  echo '========== AUTOMATED REGRESSION TESTS =========='
  java -cp build/classes tests.DesignPatternsTests
  for task in 1 2 3 4 5; do
    echo
    echo "========== TASK ${task} RUNNER =========="
    java -cp build/classes "task${task}.Task${task}Runner"
  done
} | tee output/verification.txt
