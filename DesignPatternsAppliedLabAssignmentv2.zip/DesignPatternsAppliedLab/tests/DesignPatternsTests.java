package tests;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.atomic.AtomicInteger;
import task1.*;
import task2.*;
import task3.*;
import task4.*;
import task5.*;

/** Java SE 8 self-contained regression tests; no JUnit or external libraries. */
public final class DesignPatternsTests {
    private static int checks;
    private static void ok(boolean value, String label) {
        checks++;
        if (!value) throw new AssertionError(label);
    }
    private static void eq(double a, double b, String label) {
        ok(Math.abs(a - b) < 0.000001, label + ": expected " + b + ", got " + a);
    }
    private static void has(String value, String fragment, String label) {
        ok(value.contains(fragment), label + ": expected fragment '" + fragment + "'");
    }
    private static String capture(Runnable callback) {
        PrintStream original = System.out;
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try {
            System.setOut(new PrintStream(buffer, true, "UTF-8"));
            callback.run();
        } catch (java.io.UnsupportedEncodingException e) {
            throw new AssertionError(e);
        } finally {
            System.setOut(original);
        }
        return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
    }
    private static void task1() {
        String json = new JsonFormatter().format("T\"est", new String[]{"x"}, new String[][]{{"a\\b\nc"}});
        has(json, "T\\\"est", "JSON quotes escaped");
        has(json, "a\\\\b\\nc", "JSON backslash and newline escaped");
        String csv = new CsvFormatter().format("T", new String[]{"x"}, new String[][]{{"say \"A,B\""}});
        has(csv, "\"say \"\"A,B\"\"\"", "CSV quotes escaped");
        String output = capture(() -> new Base64EncryptDecorator(
                new HeaderFooterDecorator(new BaseFileExporter(), "2026-11-02 10:00:00 UTC"))
                .export("test.sec", "HELLO"));
        has(output, "[DISK WRITE]", "Base exporter called");
        String prefix = "[BASE64_CIPHERTEXT:";
        int start = output.indexOf(prefix);
        ok(start >= 0, "Base64 marker present");
        String value = output.substring(start + prefix.length(), output.indexOf(']', start));
        String decoded = new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8);
        has(decoded, "METADATA HEADER:", "Header included inside Base64");
        has(decoded, "HELLO", "Body included inside Base64");
        has(decoded, "INTEGRITY CHECK:", "Footer included inside Base64");
        String counted = capture(() -> new HeaderFooterDecorator(new BaseFileExporter(), "stamp", 2)
                .export("test.sec", "HELLO"));
        has(counted, "--- EXPORT TIMESTAMP: stamp ---", "Prose header variant");
        has(counted, "--- RECORD COUNT: 2 | SECURE HASH: [OK] ---", "Prose footer variant");
    }
    private static void task2() {
        StockProvider adapter = new StockFeedAdapter(new LegacyStockFeed());
        eq(adapter.getMarketPrice("AAPL"), 183, "AAPL midpoint");
        eq(adapter.getMarketPrice("GOOGL"), 164.5, "GOOGL midpoint");
        ok("OPEN".equals(adapter.getStatus("AAPL")), "Legacy status parsing");
        AtomicInteger calls = new AtomicInteger();
        StockProvider fake = new StockProvider() {
            public double getMarketPrice(String symbol) { calls.incrementAndGet(); return 7; }
            public String getStatus(String symbol) { return "OPEN"; }
        };
        CachedStockProxy cache = new CachedStockProxy(fake, 80);
        String trace = capture(() -> {
            eq(cache.getMarketPrice("aapl"), 7, "Cold cache");
            eq(cache.getMarketPrice("AAPL"), 7, "Hot cache");
        });
        has(trace, "[NETWORK FETCH]", "Cache miss trace");
        has(trace, "[CACHE HIT]", "Cache hit trace");
        ok(calls.get() == 1, "Hot cache avoids second request");
        try { Thread.sleep(110); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        capture(() -> eq(cache.getMarketPrice("AAPL"), 7, "Expired cache"));
        ok(calls.get() == 2, "Cache refreshes on TTL expiry");
    }
    private static void task3() {
        DispatchStrategy business = new BusinessHoursStrategy();
        ok(!business.shouldDispatch(1, 8), "Before workday blocked");
        ok(business.shouldDispatch(1, 9), "At 09:00 allowed");
        ok(business.shouldDispatch(1, 17), "At 17:00 allowed");
        ok(!business.shouldDispatch(1, 18), "At 18:00 blocked");
        ok(business.shouldDispatch(5, 2), "Critical bypass at night");
        ok(new ImmediateStrategy().shouldDispatch(1, 23), "Immediate policy always sends");
        String blocked = capture(() -> new DailySummaryAlert(new EmailChannel(), business)
                .processAlert("a@b", "OK", 23));
        has(blocked, "DISPATCH SUPPRESSED", "Policy suppression logged");
        ok(!blocked.contains("EMAIL PROTOCOL"), "Suppressed message never transmitted");
        String emergency = capture(() -> new CriticalSystemAlert(new SmsChannel(), business)
                .processAlert("+1", "ERROR", 2));
        has(emergency, "SMS PROTOCOL", "Emergency delivered by SMS");
        String digest = capture(() -> new DailySummaryAlert(new EmailChannel(), business)
                .processAlert("a@b", "OK", 11));
        has(digest, "Daily Digest:", "Digest formatting");
        has(digest, "EMAIL PROTOCOL", "Workday email sent");
    }
    private static void task4() {
        PricingService base = new CurrencyOrderAdapter(new LegacyForeignOrder("O", 100),
                new LegacyCurrencyConverter(), "USD");
        eq(base.calculateTotal(), 125, "USD currency conversion");
        PricingService gift = new GiftWrapDecorator(base);
        eq(gift.calculateTotal(), 130, "Gift wrap addition");
        PricingService express = new ExpressCourierDecorator(gift);
        eq(express.calculateTotal(), 145, "Express addition");
        PricingService customs = new CustomsDutyDecorator(express);
        eq(customs.calculateTotal(), 157.33, "Exact expected rounded total");
        has(customs.getReceiptBreakdown(), "[Gift Wrap: $5.00]", "Gift receipt");
        has(customs.getReceiptBreakdown(), "[Express Courier: $15.00]", "Express receipt");
        has(customs.getReceiptBreakdown(), "[Customs Duty: 8.5%]", "Customs receipt");
        eq(new LegacyCurrencyConverter().convertRate(100, "GBP", "USD"), 125, "Currency prose alias");
    }
    private static void task5() {
        AtomicInteger calls = new AtomicInteger();
        StorageDriver physical = new StorageDriver() {
            public byte[] loadRawBlob(String path) { calls.incrementAndGet(); return new byte[]{1, 2, 3}; }
            public String getStorageType() { return "FAKE"; }
        };
        StorageDriver admin = new StorageDriverProxy(physical, new UserSession("u", "ADMIN"));
        StorageDriver guest = new StorageDriverProxy(physical, new UserSession("g", "GUEST"));
        StorageDriver fakeAdmin = new StorageDriverProxy(physical, new UserSession("x", "SUPERADMIN"));
        String allowed = capture(() -> new VideoAsset(admin, "video").render());
        has(allowed, "PROXY AUDIT", "Authorized audit log");
        has(allowed, "SUCCESS: Video playback buffered 3 bytes", "Bridge video renderer");
        ok(calls.get() == 1, "Authorized storage call executed");
        String denied = capture(() -> new AudioAsset(guest, "audio").render());
        has(denied, "PROXY BLOCKED", "Guest blocked");
        has(denied, "Audio stream inaccessible", "Denied audio failure message");
        capture(() -> fakeAdmin.loadRawBlob("privileged"));
        ok(calls.get() == 1, "Unrecognized role cannot elevate");
        ok("PROXY_GUARDED(FAKE)".equals(admin.getStorageType()), "Proxy backend label");
        ok("PROXY_GUARDED(FAKE)".equals(admin.getStorageId()), "Storage ID alias");
    }
    public static void main(String[] args) {
        task1(); System.out.println("PASS: Task 1 (Strategy + Decorator)");
        task2(); System.out.println("PASS: Task 2 (Adapter + Proxy)");
        task3(); System.out.println("PASS: Task 3 (Bridge + Strategy)");
        task4(); System.out.println("PASS: Task 4 (Adapter + Decorator)");
        task5(); System.out.println("PASS: Task 5 (Bridge + Proxy)");
        System.out.println("ALL " + checks + " CHECKS PASSED");
    }
}
