# Practical Design Patterns: Applied Engineering Lab

**Complete solution to all five tasks from `DesignPatternsAppliedLabAssignmentv2.pdf`.**

- **Platform:** Java SE 8 or later (JDK, standard library only)
- **Build:** plain `javac`; no Maven, Gradle, JUnit, or third-party frameworks
- **Source code:** `src/task1/` through `src/task5/`
- **Pre-constructed verification scenarios:** `Task1Runner` through `Task5Runner`
- **Additional tests:** `tests/DesignPatternsTests.java` (47 assertions)
- **Recorded execution:** `output/verification.txt`

## Run on Windows

1. Install a Java **JDK** (8 or higher). Run `java -version` and `javac -version` to verify.
2. Extract the entire project ZIP.
3. Open the project folder in the terminal (cmd or PowerShell).
4. Run `run.bat`. The script compiles everything, runs the regression tests and all five assignment runners, and saves the output to `output/verification.txt`.

Alternatively, open the folder in IntelliJ IDEA and run each `taskN.TaskNRunner` directly (JDK 8+; source root is `src`).

## Run on macOS / Linux

```bash
chmod +x run.sh
./run.sh
```

## Run a specific task manually

First run `run.sh` or `run.bat` to compile, then choose a runner:

```bash
java -cp build/classes task1.Task1Runner
java -cp build/classes task2.Task2Runner
java -cp build/classes task3.Task3Runner
java -cp build/classes task4.Task4Runner
java -cp build/classes task5.Task5Runner
java -cp build/classes tests.DesignPatternsTests
```

On Windows, write `build\classes` instead of `build/classes` if needed.

## File layout

```text
DesignPatternsAppliedLab/
├── src/
│   ├── task1/   Strategy + Decorator: report exporter
│   ├── task2/   Adapter + Proxy: stock feeds and TTL cache
│   ├── task3/   Bridge + Strategy: alert routing and dispatch policies
│   ├── task4/   Adapter + Decorator: international order pricing
│   └── task5/   Bridge + Proxy: cloud assets and RBAC
├── tests/DesignPatternsTests.java
├── docs/EXPLANATION_RU.md
├── output/verification.txt
├── run.sh
└── run.bat
```

## Requirements covered

| Task | Pattern combination | Demonstrated behavior |
|---|---|---|
| 1 | Strategy + Decorator | JSON and CSV strategies; export to console with metadata and Base64 payload |
| 2 | Adapter + Proxy | Legacy semicolon packet parsing; midpoint BID/ASK; cached and expired price responses |
| 3 | Bridge + Strategy | SMS/email delivery; immediate/business-hours policies; severity 5 override |
| 4 | Adapter + Decorator | 100 GBP -> $125; +$5 gift, +$15 courier, +8.5% customs -> **$157.33** |
| 5 | Bridge + Proxy | S3 and NFS drivers; video and audio abstractions; ADMIN allowed, GUEST denied |

## Source PDF inconsistencies / explicit decisions

Some prose requirements and supplied skeletons differ from the examples. The solution preserves the names and **behavior of all five original `TaskNRunner` programs** and documents the choices:

1. **Task 1:** The prose specifies `--- EXPORT TIMESTAMP ... ---` and a `RECORD COUNT` footer, while the skeleton's original two-argument `HeaderFooterDecorator` prints `=== METADATA HEADER... ===` and `=== INTEGRITY CHECK... ===`. The two-argument constructor reproduces the skeleton's texts. An additional overload accepting `(Exporter, timestamp, rowCount)` supports the prose version. A composite transformation pipeline ensures Base64 is applied *after* the header/footer transformation, so the entire payload is encoded, as in the PDF's Base64 example. This means the actual byte count is calculated from the **complete encoded payload**, not the PDF's visually clipped one-line excerpt (`236 bytes` in its printed sample). **Base64 is encoding, not cryptographic encryption.**
2. **Task 2:** The sample hot-cache age (`2 ms`) is nondeterministic and varies with machine speed; cache hits, misses, and expiration are tested by behavior, not by exact millisecond values. The TTL limits repeated upstream price requests. No arbitrary extra throttle duration was invented (not defined in the PDF).
3. **Task 3:** The prose briefly gives an SMTP-style trace, but the skeleton and expected output use `[EMAIL PROTOCOL -> ...]` and `[SMS PROTOCOL -> ...]`. We retain those exact runner-compatible labels. An extra `send(...)` convenience API supports the prose method name.
4. **Task 4:** The source uses `Math.round(double)`, which can produce `$157.32` because of floating-point representation. This implementation uses standard-library `BigDecimal` + `HALF_UP`, producing the **required `$157.33`** reliably.
5. **Task 5:** The prose mentions `getStorageId()`, but the runner uses `getStorageType()`. Both are provided (the former is a Java 8 default interface method). Access is granted to `ADMIN`, `MEMBER`, `ENGINEER`, and rejected for guests or any unrecognized role.

For each task, `TaskNRunner` uses the same scenario, input data, and execution order supplied in the original PDF. No external services, file writing, or network connectivity are required: those operations are intentionally simulated, as the assignment specifies.

## Git / submission

The ZIP includes a local Git history with separate commits for tasks 1–5 and the verification suite. To submit as an **individual remote repository**, create your own empty GitHub/GitLab repository, then from this project directory run:

```bash
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
git branch -M main
git push -u origin main
```

Replace the URL with your repository's real URL. **No remote push is performed automatically**; the Git host and credentials must be provided by the submitting student.
