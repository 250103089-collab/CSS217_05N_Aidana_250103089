# Объяснение лабораторной работы (к защите)

## Task 1 — Strategy + Decorator

**Задача:** сформировать отчёт в JSON/CSV и пропустить его через защищённый конвейер экспорта.

**Strategy:** интерфейс `ReportFormatter` определяет единый метод `format(...)`; `JsonFormatter` и `CsvFormatter` реализуют два разных алгоритма форматирования без изменения вызывающего кода.

**Decorator:** интерфейс `Exporter` реализуют `BaseFileExporter` и декораторы `HeaderFooterDecorator` / `Base64EncryptDecorator`. Декораторы могут сочетаться во время выполнения. В раннере конфигурация `Base64(HeaderFooter(BaseFileExporter))` кодирует в Base64 целиком заголовок, отчёт и конец. Base64 — именно кодирование, а не настоящая криптография.

## Task 2 — Adapter + Proxy

**Задача:** получать цену акции из устаревшего API и уменьшать число дорогих обращений.

**Adapter:** `StockFeedAdapter` переводит строку `TICKER=...;BID=...;ASK=...;STATUS=...` в интерфейс `StockProvider`. Цена `(BID + ASK) / 2`; для AAPL это `(182.50 + 183.50) / 2 = $183.00`.

**Proxy:** `CachedStockProxy` проверяет кеш по ключу тикера. Первый запрос обращается к адаптеру, следующий запрос — кеш-хит. После истечения TTL в 1500 мс стоимость перечитывается.

## Task 3 — Bridge + Strategy

**Задача:** отправлять оповещения по SMS или Email при соблюдении политики времени.

**Bridge:** `Alert` содержит ссылку на `MessageChannel`; `CriticalSystemAlert` и `DailySummaryAlert` можно комбинировать с любым каналом (`SmsChannel`, `EmailChannel`). Тип сообщения не зависит от протокола передачи.

**Strategy:** `DispatchStrategy` решает, разрешена ли отправка. `ImmediateStrategy` всегда разрешает. `BusinessHoursStrategy` разрешает с 09:00 до 17:00 включительно; серьёзность >= 5 обходит ограничение и отправляет критическое сообщение даже в 02:00.

## Task 4 — Adapter + Decorator

**Задача:** сконвертировать GBP в USD и добавить несколько комиссий.

**Adapter:** `CurrencyOrderAdapter` превращает `LegacyForeignOrder` в интерфейс `PricingService` и применяет конверсию 1 GBP = 1.25 USD.

**Decorator:** цепочка `CustomsDutyDecorator(ExpressCourierDecorator(GiftWrapDecorator(base)))` поэтапно добавляет фиксированные сборы и налог:

```text
100 GBP × 1.25 = $125.00
Gift wrap        + $5.00   = $130.00
Express courier  + $15.00  = $145.00
Customs (8.5%)              = $157.325 → $157.33
```

Округление сделано через `BigDecimal` для точного ответа из условия.

## Task 5 — Bridge + Proxy

**Задача:** запускать аудио/видео с разных физических хранилищ с RBAC-проверкой.

**Bridge:** `DigitalAsset` (абстракция) использует интерфейс `StorageDriver` (реализация). Поэтому `VideoAsset` и `AudioAsset` работают и с S3, и с NFS без зависимости от конкретного устройства.

**Proxy:** `StorageDriverProxy` получает текущую сессию `UserSession`, проверяет роль и делегирует загрузку только авторизованным пользователям. Для `ADMIN` отображаются аудит и успешная загрузка четырёх байтов; для `GUEST` запрос блокируется, базовый драйвер вообще не вызывается.

## Самопроверка

Запустите `run.bat` (Windows) или `./run.sh` (macOS/Linux). Вывод должен содержать:

```text
PASS: Task 1 (Strategy + Decorator)
PASS: Task 2 (Adapter + Proxy)
PASS: Task 3 (Bridge + Strategy)
PASS: Task 4 (Adapter + Decorator)
PASS: Task 5 (Bridge + Proxy)
ALL 47 CHECKS PASSED
```

Файл `output/verification.txt` содержит результаты всех пяти стандартных раннеров из PDF.
