package task5;

public interface StorageDriver {
    byte[] loadRawBlob(String resourceUri);
    String getStorageType();

    /** Compatibility alias for getStorageId() mentioned in the task prose. */
    default String getStorageId() {
        return getStorageType();
    }
}
