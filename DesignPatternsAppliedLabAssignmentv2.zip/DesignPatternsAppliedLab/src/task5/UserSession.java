package task5;

public class UserSession {
    private final String username;
    private final String role;

    public UserSession(String username, String role) {
        if (username == null || role == null) throw new IllegalArgumentException("User/session fields cannot be null");
        this.username = username;
        this.role = role;
    }

    public String getUsername() { return username; }
    public String getRole() { return role; }
}
