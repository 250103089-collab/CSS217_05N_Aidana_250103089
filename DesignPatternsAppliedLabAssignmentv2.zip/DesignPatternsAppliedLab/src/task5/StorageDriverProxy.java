package task5;

/** RBAC proxy: only ADMIN, MEMBER and ENGINEER may reach the storage backend. */
public class StorageDriverProxy implements StorageDriver {
    private final StorageDriver realDriver;
    private final UserSession session;

    public StorageDriverProxy(StorageDriver realDriver, UserSession session) {
        if (realDriver == null || session == null) {
            throw new IllegalArgumentException("Dependencies cannot be null");
        }
        this.realDriver = realDriver;
        this.session = session;
    }

    @Override
    public byte[] loadRawBlob(String resourceUri) {
        String role = session.getRole();
        boolean permitted = "ADMIN".equalsIgnoreCase(role)
                || "MEMBER".equalsIgnoreCase(role)
                || "ENGINEER".equalsIgnoreCase(role);
        if (!permitted) {
            System.out.printf("[PROXY BLOCKED] Access Denied for User '%s' [Role: %s] on resource: %s%n",
                    session.getUsername(), role, resourceUri);
            return new byte[0];
        }
        System.out.printf("[PROXY AUDIT] Authorized user '%s' [Role: %s] accessing backend: %s%n",
                session.getUsername(), role, realDriver.getStorageType());
        return realDriver.loadRawBlob(resourceUri);
    }

    @Override
    public String getStorageType() {
        return "PROXY_GUARDED(" + realDriver.getStorageType() + ")";
    }
}
