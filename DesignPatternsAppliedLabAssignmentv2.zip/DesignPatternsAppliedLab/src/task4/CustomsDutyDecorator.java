package task4;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class CustomsDutyDecorator extends PricingDecorator {
    public CustomsDutyDecorator(PricingService wrapped) { super(wrapped); }

    @Override
    public double calculateTotal() {
        // Decimal arithmetic avoids a binary floating-point tie error:
        // 145.00 * 1.085 is exactly 157.325 -> HALF_UP = 157.33.
        return BigDecimal.valueOf(super.calculateTotal())
                .multiply(new BigDecimal("1.085"))
                .setScale(2, RoundingMode.HALF_UP)
                .doubleValue();
    }

    @Override
    public String getReceiptBreakdown() {
        return super.getReceiptBreakdown() + " + [Customs Duty: 8.5%]";
    }
}
