package task1;

import java.util.Objects;

public class CsvFormatter implements ReportFormatter {
    @Override
    public String format(String title, String[] headers, String[][] rows) {
        Objects.requireNonNull(title, "title");
        Objects.requireNonNull(headers, "headers");
        Objects.requireNonNull(rows, "rows");
        StringBuilder sb = new StringBuilder("# TITLE: ").append(title).append('\n');
        appendRow(sb, headers);
        for (String[] row : rows) {
            if (row == null || row.length != headers.length) {
                throw new IllegalArgumentException("Each row must match the header count");
            }
            appendRow(sb, row);
        }
        return sb.toString();
    }

    private static void appendRow(StringBuilder sb, String[] columns) {
        for (int i = 0; i < columns.length; i++) {
            if (i != 0) sb.append(',');
            // RFC 4180-compatible quoted cells (including escaped double quotes).
            sb.append('"').append(Objects.requireNonNull(columns[i], "CSV cell")
                    .replace("\"", "\"\"")).append('"');
        }
        sb.append('\n');
    }
}
