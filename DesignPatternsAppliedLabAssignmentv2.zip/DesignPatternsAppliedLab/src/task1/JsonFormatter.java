package task1;

import java.util.Objects;

public class JsonFormatter implements ReportFormatter {
    @Override
    public String format(String title, String[] headers, String[][] rows) {
        Objects.requireNonNull(title, "title");
        Objects.requireNonNull(headers, "headers");
        Objects.requireNonNull(rows, "rows");
        StringBuilder sb = new StringBuilder();
        sb.append("{\n \"report\": \"").append(escape(title)).append("\",\n \"records\": [\n");
        for (int i = 0; i < rows.length; i++) {
            if (rows[i] == null || rows[i].length != headers.length) {
                throw new IllegalArgumentException("Each row must match the header count");
            }
            sb.append(" {");
            for (int j = 0; j < headers.length; j++) {
                sb.append("\"").append(escape(headers[j])).append("\": \"")
                  .append(escape(rows[i][j])).append("\"");
                if (j < headers.length - 1) sb.append(", ");
            }
            sb.append("}").append(i < rows.length - 1 ? ",\n" : "\n");
        }
        sb.append(" ]\n}");
        return sb.toString();
    }

    /** Escape strings according to JSON string syntax, no external libraries. */
    private static String escape(String s) {
        Objects.requireNonNull(s, "JSON string field");
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': out.append("\\\\"); break;
                case '"': out.append("\\\""); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                case '\b': out.append("\\b"); break;
                case '\f': out.append("\\f"); break;
                default:
                    if (c < 0x20) {
                        out.append(String.format(java.util.Locale.ROOT, "\\u%04x", (int)c));
                    } else out.append(c);
            }
        }
        return out.toString();
    }
}
