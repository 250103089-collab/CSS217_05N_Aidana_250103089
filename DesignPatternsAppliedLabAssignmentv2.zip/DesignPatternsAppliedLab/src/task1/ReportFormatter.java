package task1;

/** Strategy contract: a data set may be formatted independently of export. */
public interface ReportFormatter {
    String format(String title, String[] headers, String[][] rows);
}
