package task1;

import java.util.Objects;

public class HeaderFooterDecorator extends ExporterDecorator {
    private final String timestamp;
    private final Integer recordCount;

    /** The exact two-argument constructor used by the PDF's immutable runner. */
    public HeaderFooterDecorator(Exporter wrappedExporter, String timestamp) {
        super(wrappedExporter);
        this.timestamp = Objects.requireNonNull(timestamp, "timestamp");
        this.recordCount = null;
    }

    /** Optional specification-style variant when the row count is supplied. */
    public HeaderFooterDecorator(Exporter wrappedExporter, String timestamp, int rowCount) {
        super(wrappedExporter);
        if (rowCount < 0) throw new IllegalArgumentException("rowCount cannot be negative");
        this.timestamp = Objects.requireNonNull(timestamp, "timestamp");
        this.recordCount = rowCount;
    }

    @Override
    protected String transform(String data) {
        // The original runner uses the document's complete skeleton-code labels.
        if (recordCount == null) {
            return "=== METADATA HEADER: " + timestamp + " ===\n" + data + "\n"
                    + "=== INTEGRITY CHECK: SHA-256 OK | END RECORD ===";
        }
        // Alternative from the prose requirement, useful with an explicit count.
        return "--- EXPORT TIMESTAMP: " + timestamp + " ---\n" + data + "\n"
                + "--- RECORD COUNT: " + recordCount + " | SECURE HASH: [OK] ---";
    }
}
