package task1;

import java.util.ArrayList;
import java.util.List;

/**
 * Decorator component. For this lab, payload transformations run from the
 * innermost decorator to the outermost before delivery to BaseFileExporter.
 * Thus Base64(HeaderFooter(BaseFileExporter)) encodes the *entire* header,
 * body and footer, matching the intended secure-payload example.
 */
public abstract class ExporterDecorator implements Exporter {
    protected final Exporter wrappedExporter;

    public ExporterDecorator(Exporter wrappedExporter) {
        if (wrappedExporter == null) {
            throw new IllegalArgumentException("Wrapped exporter cannot be null");
        }
        this.wrappedExporter = wrappedExporter;
    }

    protected String transform(String payload) {
        return payload;
    }

    @Override
    public final void export(String destination, String data) {
        Exporter base = this;
        List<ExporterDecorator> chain = new ArrayList<>();
        while (base instanceof ExporterDecorator) {
            ExporterDecorator decorator = (ExporterDecorator) base;
            chain.add(decorator);
            base = decorator.wrappedExporter;
        }
        for (int i = chain.size() - 1; i >= 0; i--) {
            data = chain.get(i).transform(data);
        }
        base.export(destination, data);
    }
}
