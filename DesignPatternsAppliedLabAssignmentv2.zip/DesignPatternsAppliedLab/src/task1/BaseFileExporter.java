package task1;

import java.nio.charset.StandardCharsets;

/** Simulated disk writer as specified; does not create real files. */
public class BaseFileExporter implements Exporter {
    @Override
    public void export(String destination, String data) {
        System.out.printf("[DISK WRITE] Writing %d bytes to file://%s%n",
                data.getBytes(StandardCharsets.UTF_8).length, destination);
        System.out.println("----- FILE PAYLOAD BEGIN -----");
        System.out.println(data);
        System.out.println("----- FILE PAYLOAD END -----");
    }
}
