package task2;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Proxy shields the expensive legacy adapter behind a TTL cache. */
public class CachedStockProxy implements StockProvider {
    private static final class CacheEntry {
        final double price;
        final long timestamp;

        CacheEntry(double price, long timestamp) {
            this.price = price;
            this.timestamp = timestamp;
        }
    }

    private final StockProvider realProvider;
    private final long ttlMillis;
    private final Map<String, CacheEntry> priceCache = new HashMap<>();

    public CachedStockProxy(StockProvider realProvider, long ttlMillis) {
        if (realProvider == null) throw new IllegalArgumentException("Real provider cannot be null");
        if (ttlMillis < 0) throw new IllegalArgumentException("TTL cannot be negative");
        this.realProvider = realProvider;
        this.ttlMillis = ttlMillis;
    }

    @Override
    public synchronized double getMarketPrice(String ticker) {
        String key = ticker.toUpperCase(Locale.ROOT);
        long now = System.currentTimeMillis();
        CacheEntry cached = priceCache.get(key);
        if (cached != null && (now - cached.timestamp) < ttlMillis) {
            System.out.printf("[CACHE HIT] Returning cached price for %s: $%.2f (Age: %d ms)%n",
                    ticker, cached.price, now - cached.timestamp);
            return cached.price;
        }
        System.out.printf("[NETWORK FETCH] Cache miss or expired for %s. Calling upstream adapter...%n", ticker);
        double fresh = realProvider.getMarketPrice(ticker);
        priceCache.put(key, new CacheEntry(fresh, System.currentTimeMillis()));
        return fresh;
    }

    @Override
    public String getStatus(String ticker) {
        return realProvider.getStatus(ticker);
    }
}
